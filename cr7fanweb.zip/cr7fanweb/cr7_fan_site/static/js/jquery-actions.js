$(document).ready(function () {
    // Кнопка для галереи
    $('#toggle-gallery').click(function () {
        $('#gallery').slideToggle(600);
    });

  
});
